from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
def contar(path):
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    return {"totales": len(lines), "no_vacias": sum(bool(x.strip()) for x in lines),
            "codigo": sum(bool(x.split(";", 1)[0].strip()) for x in lines)}
print(json.dumps({"Unidad 2": contar(root / "comparacion/main_Unidad2.asm.txt"),
                  "Unidad 3": contar(root / "Proyecto_Electronica/main.asm")}, indent=2))
