from pathlib import Path
import subprocess, json, struct, shutil
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE
import tempfile
WORK=Path(tempfile.mkdtemp(prefix='electronica_u3_'))
WORK.mkdir(parents=True,exist_ok=True)
TOOLS=Path(r'C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x86')
LIB=Path(r'C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x86')
SOURCE=(ROOT/'Proyecto_Electronica/main.asm').read_text(encoding='utf-8-sig')
PREFIX=SOURCE.split('; Punto de entrada:')[0]
tests=[]
data=[]
def add(title, body, expected):
    tests.append(dict(id=len(tests)+1,entrada=title,esperado=expected,body=body))
def string(s):
    name=f'text{len(data)}'
    raw=s.encode('ascii')+b'\0'
    data.append(name+' LABEL BYTE\n'+'\n'.join('BYTE '+','.join(map(str,raw[i:i+24])) for i in range(0,len(raw),24)))
    return name
def parse(proc,s,value):
    label=string(s)
    body=f'mov esi,OFFSET {label}\ncall {proc}\n'
    body+=('jnc failure' if value is None else f'jc failure\ncmp eax,{value}\njne failure')
    add(proc+': '+repr(s),body,'Rechazado' if value is None else str(value))
for s,v in [('185.50',18550),('12.05',1205),('12.5',1250),('12',1200),('0.01',1),('9999.99',999999),('0001.20',120),('',None),('0',None),('0.00',None),('10000',None),('9999.999',None),('1.',None),('.50',None),('1.2.3',None),('$1',None),('1,000',None),('-1',None),('+1',None),(' 1',None),('1 ',None),('1e2',None),('42949672960',None)]: parse('ParsePrice',s,v)
for s,v in [('0',0),('100',100),('4294967295',4294967295),('4294967296',None),('9999999999999999999',None),('',None),('-1',None),('1.0',None),('1a',None),(' 2',None),('+1',None)]: parse('ParseUnsigned',s,v)
for proc,inputs in [('ValidateCode',[('ABC-123',True),('XYZ-000',True),('abc-123',False),('AB-123',False),('ABCD-123',False),('ABC_123',False),('ABC-12X',False),('ABC-1234',False),('',False)]),('ValidateName',[('ESP32 DevKit',True),('A',True),('A'*25,True),('A'*26,False),('',False),('   ',False),('X\tY',False)])]:
    for s,ok in inputs:
        label=string(s+'\0'*26)
        add(proc+': '+repr(s),f'mov esi,OFFSET {label}\ncall {proc}\n'+('jc failure' if ok else 'jnc failure'),'Aceptado' if ok else 'Rechazado')
for proc,values in [('UIntToString',[0,1,10,100,4294967295]),('MoneyToString',[0,1,5,100,1205,18550,999999,4294967295])]:
    for v in values:
        expected=str(v) if proc=='UIntToString' else f'{v//100}.{v%100:02} MXN'
        label=string(expected)
        add(f'{proc}: {v}',f'mov eax,{v}\nmov edi,OFFSET testOutput\ncall {proc}\nmov esi,OFFSET testOutput\nmov edi,OFFSET {label}\nmov ecx,{len(expected)+1}\nrepe cmpsb\njne failure',expected)
seed=(ROOT/'inventario.dat').read_bytes()
data.append('seed LABEL BYTE\n'+'\n'.join('BYTE '+','.join(map(str,seed[i:i+24])) for i in range(0,len(seed),24)))
fixture='call ResetFixture\n'
add('Resumen de tres productos',fixture+'call ComputeSummary\njc failure\ncmp eax,44\njne failure\ncmp edx,193500\njne failure','44 unidades; 1935.00 MXN')
for code,off in [('ESP-032',0),('RES-220',44),('LED-005',88),('NUL-000',None)]:
    label=string(code)
    b=fixture+f'mov edx,OFFSET {label}\ncall FindProduct\n'
    b+=('test eax,eax\njnz failure' if off is None else f'lea edx,catalog+{off}\ncmp eax,edx\njne failure')
    add('Busqueda '+code,b,'No encontrado' if off is None else f'Registro {off//44+1}')
for qty,ok,new in [(5,True,15),(90,True,100),(91,False,10),(0,False,10),(101,False,10),(4294967295,False,10)]:
    b=fixture+f'mov esi,OFFSET catalog\nmov eax,{qty}\ncall ReceiveStock\n'+('jc failure' if ok else 'jnc failure')+f'\ncmp catalog.stock,{new}\njne failure\ncmp dirty,{1 if ok else 0}\njne failure'
    add('Entrada sobre stock 10: '+str(qty),b,f'{"Aceptada" if ok else "Rechazada"}; stock {new}')
for qty,ok,new,income in [(2,True,8,37100),(10,True,0,185500),(11,False,10,0),(0,False,10,0),(101,False,10,0)]:
    b=fixture+f'mov esi,OFFSET catalog\nmov eax,{qty}\ncall SellProduct\n'+('jc failure' if ok else 'jnc failure')+f'\ncmp catalog.stock,{new}\njne failure\ncmp sessionIncome,{income}\njne failure\ncmp dirty,{1 if ok else 0}\njne failure'
    add('Venta sobre stock 10: '+str(qty),b,f'{"Aceptada" if ok else "Rechazada"}; stock {new}; ingresos {income/100:.2f} MXN')
add('Venta con ingresos cercanos a 2^32',fixture+'mov sessionIncome,0FFFFFFFFh\nmov esi,OFFSET catalog\nmov eax,1\ncall SellProduct\njnc failure\ncmp catalog.stock,10\njne failure\ncmp sessionIncome,0FFFFFFFFh\njne failure\ncmp dirty,0\njne failure','Rechazo por desbordamiento; stock e ingresos sin cambios')
for stock in [0,4,5,6,100]:
    add('Alerta con stock '+str(stock),fixture+f'mov catalog.stock,{stock}\nmov esi,OFFSET catalog\ncall IsLowStock\n'+('jnc failure' if stock<=5 else 'jc failure'),'Alerta' if stock<=5 else 'Sin alerta')
candidate='mov esi,OFFSET catalog\nmov edi,OFFSET candidate\nmov ecx,SIZEOF Product\nrep movsb\n'
add('Alta duplicada ESP-032',fixture+candidate+'call RegisterCandidate\njnc failure\ncmp productCount,3\njne failure\ncmp dirty,0\njne failure','Rechazada; tres productos sin cambios')
newcode=string('USB-001')
newcandidate=candidate+f'mov esi,OFFSET {newcode}\nmov edi,OFFSET candidate\nmov ecx,8\nrep movsb\n'
add('Alta USB-001 valida',fixture+newcandidate+'call RegisterCandidate\njc failure\ncmp productCount,4\njne failure\ncmp dirty,1\njne failure','Aceptada; cuatro productos')
add('Alta con diez productos',fixture+newcandidate+'mov productCount,10\ncall RegisterCandidate\njnc failure\ncmp productCount,10\njne failure\ncmp dirty,0\njne failure','Rechazada por capacidad')
for field,val in [('price',0),('price',1000000),('stock',101)]:
    add(f'Alta con {field}={val}',fixture+newcandidate+f'mov candidate.{field},{val}\ncall RegisterCandidate\njnc failure\ncmp productCount,3\njne failure\ncmp dirty,0\njne failure','Rechazada sin alta parcial')
def filetest(title,changes,ok,length=140):
    b='call ResetFixture\ncall SeedBuffer\n'+changes+f'\nmov eax,{length}\ncall ValidateFile\n'+('jc failure' if ok else 'jnc failure')+'\ncmp productCount,3\njne failure'
    add(title,b,'Archivo aceptado' if ok else 'Archivo rechazado; catalogo conservado')
filetest('Archivo valido de tres productos','',True)
filetest('Archivo con firma incorrecta','mov BYTE PTR fileBuffer,0',False)
filetest('Archivo con 11 productos','mov DWORD PTR fileBuffer[4],11',False)
filetest('Archivo truncado','',False,139)
filetest('Archivo con bytes extra','',False,141)
filetest('Archivo vacio','',False,0)
filetest('Archivo con precio cero','mov DWORD PTR fileBuffer[44],0',False)
filetest('Archivo con precio excesivo','mov DWORD PTR fileBuffer[44],1000000',False)
filetest('Archivo con stock 101','mov DWORD PTR fileBuffer[48],101',False)
filetest('Archivo con codigo minusculo',"mov BYTE PTR fileBuffer[8],'a'",False)
filetest('Archivo con codigo duplicado','mov eax,DWORD PTR fileBuffer[8]\nmov DWORD PTR fileBuffer[52],eax\nmov eax,DWORD PTR fileBuffer[12]\nmov DWORD PTR fileBuffer[56],eax',False)
filetest('Archivo con nombre sin terminador',"mov edi,OFFSET fileBuffer+16\nmov ecx,26\nmov al,'X'\nrep stosb",False)
filetest('Archivo con relleno alterado','mov BYTE PTR fileBuffer[41],1',False)
filetest('Archivo con reservado distinto de cero','mov WORD PTR fileBuffer[42],1',False)
filetest('Archivo valido sin productos','mov DWORD PTR fileBuffer[4],0',True,8)
add('Pila y conservacion en UIntToString', 'mov savedEsp,esp\nmov eax,123456\nmov ebx,11223344h\nmov ecx,55667788h\nmov edx,12345678h\nmov esi,87654321h\nmov edi,OFFSET testOutput\ncall UIntToString\ncmp esp,savedEsp\njne failure\ncmp eax,123456\njne failure\ncmp ebx,11223344h\njne failure\ncmp ecx,55667788h\njne failure\ncmp edx,12345678h\njne failure\ncmp esi,87654321h\njne failure\ncmp edi,OFFSET testOutput\njne failure','ESP y registros conservados')
helpers='''
SeedBuffer PROC USES eax ecx esi edi
    mov esi,OFFSET seed
    mov edi,OFFSET fileBuffer
    mov ecx,140
    cld
    rep movsb
    ret
SeedBuffer ENDP
ResetFixture PROC USES eax ecx esi edi
    mov edi,OFFSET catalog
    xor eax,eax
    mov ecx,SIZEOF catalog
    cld
    rep stosb
    mov esi,OFFSET seed+8
    mov edi,OFFSET catalog
    mov ecx,132
    rep movsb
    mov productCount,3
    mov dirty,0
    mov sessionIncome,0
    ret
ResetFixture ENDP
'''
def build_run(name, body, cwd=WORK):
    asm=PREFIX+'\n.data\ncurrentTest DWORD 0\nsavedEsp DWORD 0\ntestOutput BYTE 32 DUP(0)\n'+'\n'.join(data)+'\n.code\n'+helpers+'\nmain PROC\ncld\n'+body+'\nINVOKE ExitProcess,0\nfailure:\nINVOKE ExitProcess,currentTest\nmain ENDP\nEND main\n'
    src=WORK/(name+'.asm');obj=WORK/(name+'.obj');exe=WORK/(name+'.exe')
    src.write_text(asm,encoding='utf-8')
    commands=[[str(TOOLS/'ml.exe'),'/nologo','/c','/coff','/Zi','/safeseh','/I',r'C:\Irvine','/Fo'+str(obj),str(src)], [str(TOOLS/'link.exe'),'/nologo','/subsystem:console','/machine:x86','/debug','/out:'+str(exe),str(obj),r'C:\Irvine\Irvine32.lib',str(LIB/'kernel32.lib'),str(LIB/'user32.lib')]]
    for cmd in commands:
        p=subprocess.run(cmd,capture_output=True,text=True)
        if p.returncode: raise RuntimeError(p.stdout+p.stderr)
    p=subprocess.run([str(exe)],cwd=cwd,capture_output=True,timeout=15)
    if p.returncode: raise RuntimeError(f'{name}: fallo en prueba {p.returncode}')
    return p.returncode

for proc,setup,expected in [
    ('CopyBytes','mov esi,OFFSET seed+8\nmov edi,OFFSET candidate\nmov ecx,44','cmp candidate.price,18550\njne failure'),
    ('ClearBytes','mov edi,OFFSET candidate\nmov ecx,44','cmp candidate.price,0\njne failure'),
    ('ParsePrice','mov esi,OFFSET '+string('12.05'),'cmp eax,1205\njne failure'),
    ('FindProduct','mov edx,OFFSET '+string('ESP-032'),'cmp eax,OFFSET catalog\njne failure'),
    ('SellProduct','mov esi,OFFSET catalog\nmov eax,2','cmp eax,37100\njne failure'),
    ('ComputeSummary','','cmp eax,44\njne failure\ncmp edx,193500\njne failure')]:
    body=fixture+setup+'\nmov ebx,12345678h\nmov ebp,76543210h\nmov savedEsp,esp\npush ecx\npush esi\npush edi\ncall '+proc+'\n'+expected+'\ncmp ebx,12345678h\njne failure\ncmp ebp,76543210h\njne failure\npop eax\ncmp edi,eax\njne failure\npop eax\ncmp esi,eax\njne failure\npop eax\ncmp ecx,eax\njne failure\ncmp esp,savedEsp\njne failure'
    add('U3: USES, pila y resultado de '+proc,body,'Registros conservados, ESP equilibrado y resultado correcto')

body='\n'.join(f'mov currentTest,{t["id"]}\n'+t['body']+'\n' for t in tests)
build_run('pruebas_nucleo',body)
print(f'{len(tests)} pruebas del codigo MASM: OK')
for t in tests: t['obtenido']=t['esperado']+' (verificado en MASM)'
def phase(name,body,expected):
    build_run(name,'mov currentTest,1\n'+body)
    tests.append(dict(id=len(tests)+1,entrada=name,esperado=expected,obtenido=expected+' (verificado en proceso separado)'))
phase('guardar_catalogo','call ResetFixture\nmov dirty,1\ncall SaveCatalog\njc failure\ncmp dirty,0\njne failure','Archivo guardado; cambios pendientes desactivados')
assert (WORK/'inventario.dat').read_bytes()==seed
phase('cargar_nueva_ejecucion','mov sessionIncome,123\ncall LoadCatalog\njc failure\ncmp productCount,3\njne failure\ncmp catalog.price,18550\njne failure\ncmp catalog.stock,10\njne failure\ncmp sessionIncome,123\njne failure','Tres productos recuperados; ingresos de sesion conservados')
(WORK/'inventario.dat').rename(WORK/'inventario_respaldo.dat')
phase('archivo_ausente','call ResetFixture\nmov dirty,1\ncall LoadCatalog\njnc failure\ncmp productCount,3\njne failure\ncmp catalog.stock,10\njne failure\ncmp dirty,1\njne failure','Error; catalogo y cambios pendientes conservados')
(WORK/'inventario.dat').write_bytes(b'INVALIDO')
phase('archivo_invalido','call ResetFixture\nmov dirty,1\ncall LoadCatalog\njnc failure\ncmp productCount,3\njne failure\ncmp catalog.stock,10\njne failure\ncmp dirty,1\njne failure','Error; catalogo y cambios pendientes conservados')
(WORK/'inventario.dat').write_bytes(seed)
# Una carpeta con el nombre del temporal provoca un error de creacion real.
(WORK/'inventario.tmp').mkdir(exist_ok=True)
phase('fallo_guardado','call ResetFixture\nmov dirty,1\ncall SaveCatalog\njnc failure\ncmp dirty,1\njne failure','Error de escritura; cambios pendientes conservados')
assert (WORK/'inventario.dat').read_bytes()==seed
# Resultado maximo legal del inventario: 10*100*999999 centavos.
phase('resumen_limite','call ResetFixture\nmov productCount,10\nmov esi,OFFSET catalog\nmov ecx,10\nmaxloop:\nmov (Product PTR [esi]).price,999999\nmov (Product PTR [esi]).stock,100\nadd esi,SIZEOF Product\nloop maxloop\ncall ComputeSummary\njc failure\ncmp eax,1000\njne failure\ncmp edx,999999000\njne failure','1000 unidades; 9999990.00 MXN')
(WORK/'resultados.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'TOTAL: {len(tests)} pruebas satisfactorias; archivo y fallos reales incluidos.')

print("Evidencia de esta ejecucion:", WORK / "resultados.json")
